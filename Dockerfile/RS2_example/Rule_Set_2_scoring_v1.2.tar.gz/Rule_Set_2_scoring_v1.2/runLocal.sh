#!/bin/bash

if [ $# != 2 ];
then
	echo "Usage: $0 <INPUTFILE> <OUTPUTFILE>";
	exit;
fi

INPUTFILE=$1
OUTPUTFILE=$2

while read line;
do
	python rs2_score_calculator_v1.2.py --seq `cut -f 11 -d\, $line` |cut -f2 -d\: |sed 's/ //g' >> $OUTPUTFILE;
done < $INPUTFILE

